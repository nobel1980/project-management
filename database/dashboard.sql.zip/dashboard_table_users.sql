
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('Administrator','Developer','User') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'User',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `role`, `created_at`, `updated_at`) VALUES
(1, 'Masum Ahmed', 'admin@genex.com', NULL, '$2y$10$jcVoAF3qKZf7A4RpRhXisuJXcrKybyO7MW0utQUe/1A3Pi39E9gea', NULL, 'Administrator', '2024-11-05 00:26:07', '2024-11-05 00:26:07'),
(2, 'Shahidul', 'dev1@genex.com', NULL, '$2y$10$MAJ6yuooSTSf8FxUNDTKouWJBlQfvFntifd49dwWNTfpVXIVn/83y', NULL, 'Developer', '2024-11-05 00:26:08', '2024-11-05 00:26:08'),
(3, 'Tuhin', 'dev2@genex.com', NULL, '$2y$10$qZWJ8UHIgk2/7j2Vx64AMu6zCh4P4uLnhstFzD.x8JsR66YfBXXeS', NULL, 'Developer', '2024-11-05 00:26:08', '2024-11-05 00:26:08'),
(4, 'Sumon', 'dev3@genex.com', NULL, '$2y$10$nW2UraTkGz6ZOPOVryT88uijyVrRGZZuC1Y/GvxBd4iBLh5a0duru', NULL, 'Developer', '2024-11-05 00:26:08', '2024-11-05 00:26:08'),
(5, 'Zaman', 'user1@genex.com', NULL, '$2y$10$WP.sEz/BbSvfedoE.H.2ZeioEzjy.6NvztUj4TKTdJLdzN5ARBI/6', NULL, 'User', '2024-11-05 00:26:08', '2024-11-05 00:26:08'),
(6, 'Rakim', 'user2@genex.com', NULL, '$2y$10$6RXPZFCHdCaQwpOxhTwmzO/9OPHlNLWY1BjVC9eMSpuA9VH4ruMRy', NULL, 'User', '2024-11-05 00:26:08', '2024-11-05 00:26:08');
