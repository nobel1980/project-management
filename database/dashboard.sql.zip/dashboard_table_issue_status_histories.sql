
-- --------------------------------------------------------

--
-- Table structure for table `issue_status_histories`
--

DROP TABLE IF EXISTS `issue_status_histories`;
CREATE TABLE IF NOT EXISTS `issue_status_histories` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `issue_id` bigint UNSIGNED NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `changed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `issue_status_histories_issue_id_foreign` (`issue_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `issue_status_histories`
--

INSERT INTO `issue_status_histories` (`id`, `issue_id`, `status`, `changed_at`, `created_at`, `updated_at`) VALUES
(1, 11, 'Open', '2024-11-06 23:20:21', '2024-11-06 23:20:21', '2024-11-06 23:20:21');
