
-- --------------------------------------------------------

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
CREATE TABLE IF NOT EXISTS `issues` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `project_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `requested_date` date NOT NULL,
  `tentative_completion_date` date NOT NULL,
  `status` enum('Open','In Progress','Done','Review','Approved','Failed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Open',
  `assigned_user_id` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activities_project_id_foreign` (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `issues`
--

INSERT INTO `issues` (`id`, `project_id`, `name`, `description`, `requested_date`, `tentative_completion_date`, `status`, `assigned_user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 'Invoice  API', 'Sale API for invoice', '2024-10-27', '2024-10-31', 'Open', 2, '2024-10-27 04:41:53', '2024-11-03 04:22:13'),
(2, 1, 'log file medifiled', 'Log file modiled', '2024-10-27', '2024-11-07', 'In Progress', 2, '2024-10-27 04:43:24', '2024-11-03 04:22:21'),
(3, 1, 'Separate log file generate', 'Separate log file generate', '2024-10-16', '2024-10-26', 'Open', 2, '2024-10-27 04:45:38', '2024-11-03 04:22:01'),
(4, 2, 'Database migration', 'Database migration', '2024-10-21', '2024-10-31', 'In Progress', 2, '2024-10-27 06:07:02', '2024-11-03 04:19:49'),
(5, 6, 'Sales log file with new API', 'Sales log file with new API', '2024-10-28', '2024-11-04', 'Open', 2, '2024-10-29 03:09:44', '2024-11-03 04:21:34'),
(6, 1, 'Test API auth', 'Test API auth', '2024-11-03', '2024-11-20', 'Approved', 2, '2024-11-03 02:22:56', '2024-11-03 04:22:43'),
(7, 1, 'Issue 1', 'Issue 1 Desc', '2024-11-03', '2024-11-12', 'Open', 0, '2024-11-03 05:24:23', '2024-11-03 05:24:23'),
(8, 3, 'SDC Issue 1', 'SDC Issue 1 Desc', '2024-11-06', '2024-11-07', 'Open', 3, '2024-11-06 04:56:36', '2024-11-06 04:56:36'),
(9, 3, 'Apps not install', 'Apps not install', '2024-11-07', '2024-11-21', 'Open', 3, '2024-11-06 23:06:28', '2024-11-06 23:06:28'),
(10, 2, 'Add seperate table for status history', 'Add seperate table for status history with timestamp', '2024-11-07', '2024-11-08', 'Open', 3, '2024-11-06 23:16:30', '2024-11-06 23:16:30'),
(11, 2, 'Add seperate table for status history', 'Add seperate table for status history with timestamp', '2024-11-07', '2024-11-08', 'Open', 3, '2024-11-06 23:20:21', '2024-11-06 23:20:21');
