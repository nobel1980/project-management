
-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE IF NOT EXISTS `projects` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Middleware', 'Middleware description', '2024-10-27 03:34:11', '2024-10-27 03:34:11'),
(2, 'Dashboard', 'Dashboard Description', '2024-10-27 04:30:00', '2024-10-27 04:30:00'),
(3, 'SDC', 'SDC Description', '2024-10-27 04:30:28', '2024-10-27 04:30:28'),
(4, 'EFDMS', 'EFDMS Description', '2024-10-27 04:30:53', '2024-10-27 04:30:53'),
(5, 'abc', 'abc', '2024-10-27 07:45:39', '2024-10-27 07:45:39'),
(6, 'Socket based Android EFDMS Apps', 'Socket based Android EFDMS Apps', '2024-10-29 03:08:51', '2024-10-29 03:08:51'),
(7, 'Project 1', 'Project 1 desc', '2024-11-06 04:53:54', '2024-11-06 04:53:54');
